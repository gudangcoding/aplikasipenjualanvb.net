﻿Imports System.Data.SqlClient
Public Class LOGIN

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'JIKA TEXTBOX1 MASIH KOSONG MAKA HARUS DIISI
        If TextBox1.Text = "" Then
            MsgBox("USERNAME HARUS DIISI")
            Exit Sub

        ElseIf TextBox2.Text = "" Then
            MsgBox("PASSWORD HARUS DIISI")
            Exit Sub
        Else
            KONEKSI()
            CMD = New SqlCommand("SELECT * FROM TBLUSER WHERE USERNAME='" & TextBox1.Text & "' AND PASSWORD='" & TextBox2.Text & "'", CONN)
            DR = CMD.ExecuteReader
            If DR.HasRows Then
                MAIN_MENU.Show()
            Else
                MsgBox("USERNAME ATAU PASSWORD SALAH")
            End If
        End If
    End Sub
End Class