﻿Imports System.Data.SqlClient
Module Module1
    Public CONN As New SqlConnection
    Public DA As New SqlDataAdapter
    Public DS As New DataSet
    Public CMD As New SqlCommand
    Public DR As SqlDataReader
    Public Sub KONEKSI()
        CONN = New SqlConnection("DATA SOURCE=ASUS-PC\SQLEXPRESS;INITIAL CATALOG=DBPENJUALAN;INTEGRATED SECURITY=TRUE")
        CONN.Open()

    End Sub
End Module
