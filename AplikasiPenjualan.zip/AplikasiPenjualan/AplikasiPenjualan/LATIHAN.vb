﻿Imports System.Data.SqlClient
Public Class LATIHAN

    Sub TAMPIL()
        KONEKSI()
        DA = New SqlDataAdapter("SELECT * FROM TBLUSER", CONN)
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
    End Sub

    Private Sub LATIHAN_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TAMPIL()
    End Sub

    'UNTUK TOMBOL SIMPAN
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'PAKAI TRY UNTUK CEK ERROR PROGRAM SAAT TAMBAH DATA
        Try
            KONEKSI()
            CMD = New SqlCommand("INSERT INTO TBLUSER VALUES('" & TextBox1.Text & _
                                                            "','" & TextBox2.Text & _
                                                            "','" & TextBox3.Text & _
                                                            "','" & ComboBox1.Text & _
                                                            "')", CONN)
            CMD.ExecuteNonQuery()
            TAMPIL()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

End Class
